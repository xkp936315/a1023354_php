

<?php
$no = $_GET["no"];

$read= "SELECT * FROM user WHERE uNo=".$no;
	$readresult = mysqli_query($link, $read);
	$result = mysqli_fetch_array($readresult);
	
echo "修改個人資料";
echo "<form action='w5_updateresult.php' method='POST'>";
echo "帳號:" .$result[1]. "<br/>";
echo "<input type='hidden' name='no' value='".$result[1]."'>";
echo	"密碼:<input type='password' name='uPwd' value='".$result[2]."'/><br/>";
echo	"email:<input type='text' name='uEmail' value='".$result[4]."'/><br/>";
echo	"電話:<input type='text' name='uTel' value='".$result[5]."'/><br/>";
echo	"<input  type='submit'/>";
echo	"<input type='reset'/>";
echo "</form>";
?>
