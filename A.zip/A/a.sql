-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 產生時間： 2016-04-14 04:25:06
-- 伺服器版本: 5.7.10-log
-- PHP 版本： 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `a`
--

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE `user` (
  `uNo` int(11) NOT NULL COMMENT '編號',
  `uAccount` varchar(50) NOT NULL COMMENT '帳號',
  `uPwd` varchar(50) NOT NULL COMMENT '密碼',
  `uName` varchar(50) NOT NULL,
  `uEmail` varchar(100) NOT NULL COMMENT 'email',
  `uTel` varchar(50) NOT NULL COMMENT '電話',
  `ulogNum` varchar(100) NOT NULL COMMENT '登入次數',
  `uLastIn` date NOT NULL COMMENT '上一次登入時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `user`
--

INSERT INTO `user` (`uNo`, `uAccount`, `uPwd`, `uName`, `uEmail`, `uTel`, `ulogNum`, `uLastIn`) VALUES
(3, 'root', '123456', 'test', 'xkp936315@gmail.com', '1', '1', '0000-00-00'),
(4, 'test1', '123', '123', '123', '09', '1', '0000-00-00');

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uNo`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `uNo` int(11) NOT NULL AUTO_INCREMENT COMMENT '編號', AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
