<?php
$no = $_POST["no"];
$uAccount = $_POST["uAccount"];
$uPwd = $_POST["uPwd"];
$uEmail = $_POST["uEmail"];
$uTel = $_POST["uTel"];

$link = mysqli_connect("localhost","root","123456","a");
$sql = "UPDATE user SET uPwd='$uPwd, uEmail='$uEmail', uTel = '$uTel'   WHERE uNo=".$no;
mysqli_query($link, $sql);
	
	
//讀取資料
	$read= "SELECT * FROM user";
	$readresult = mysqli_query($link, $read);
	echo "<table border='1'>";
	echo "<tr><td>帳號</td><td>密碼</td><td>email</td><td>電話</td></tr>";
	while($result = mysqli_fetch_array($readresult))
	{
		echo "<tr>";
		echo "<td>".$result[1]. "</td><td>".$result[2]."</td><td>".$result[4]."</td><td>".$result[5]."</td>";
		echo "</tr>";
	}
	echo "</table>";
	
	mysqli_free_result($readresult);
	mysqli_close($link);
?>