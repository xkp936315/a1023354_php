<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<center>
		<h1>註冊頁面</h1>
		<form action="" method="POST">
		帳號:&nbsp;<input  type="text" name="uAccount"/ ><br><br>
		密碼:&nbsp;<input  type="password" name="uPwd"/><br><br>
		姓名:&nbsp;<input  type="text" name="uName"/ ><br><br>
		e-Mail:&nbsp;<input type="text" name="uEmail"/><br><br>
		電話:&nbsp;<input type="text" name="uTel"/><br><br>
		<input type="submit" name="submit" value="確認"/>
		<input type="reset"/>
		
		<a href="log.php">回登入頁面</a>
		</form>
	</center>
	
	<?php
	$link = mysqli_connect("localhost","root","123456","a");
	
	if (isset($_POST["uAccount"]))
	{
		$uAccount = $_POST["uAccount"];
		$uPwd = $_POST["uPwd"];
		$uName = $_POST["uName"];
		$uEmail = $_POST["uEmail"];
		$uTel = $_POST["uTel"];
	
	$sql = "INSERT INTO user(uAccount,uPwd,uName,uEmail, uTel, ulogNum) VALUES ('$uAccount', '$uPwd', '$uName', '$uEmail','$uTel', '1')";
	mysqli_query($link, $sql);
	}
	?>
</body>

</html>