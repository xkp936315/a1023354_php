
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<center>
		<h1>登入頁面</h1>
		<form action="" method="post">
		帳號:&nbsp;<input  type="text" name="uAccount" placeholder="請輸入您的帳號"/ ><br><br>
		密碼:&nbsp;<input  type="password" name="uPwd" placeholder="請輸入您的密碼"/><br><br>
		<input type="submit" name="submit" value="登入"/>
		<input type="reset" onClick="log.php"/>
		</form>
	</center>

<?php

session_start();
	$link = mysqli_connect("localhost","root","123456","a");

if(isset($_POST["uAccount"])){
	$uAccount=$_POST["uAccount"];
	$uPwd=$_POST["uPwd"];

$sql="SELECT * from user WHERE uAccount='$uAccount'AND uPwd='$uPwd'"; 
$result=mysqli_query($link,$sql);
$row=mysqli_num_rows($result);

if($row){ 
	echo "<script language = 'javascript'>"; 
	echo "alert('成功');location.href='index.php';"; 
	echo "</script>"; 
	$_SEESION['check']="yes";
//header('Location:#');
}else{

	echo "<script language = 'javascript'>"; 
	echo "alert('輸入錯誤！請重新輸入！');location.href='log.php';"; 
	echo "</script>"; 

}
}

?>
</body>
</html>