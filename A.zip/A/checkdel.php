<?php
$no = $_GET["no"];

$link = mysqli_connect("localhost","root","123456","a");
$del = "DELETE FROM user WHERE uNo =" .$no;
mysqli_query($link, $del);
?>