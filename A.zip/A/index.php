<?php
session_start();
$uAccount = $_GET["uAccount"];

$link = mysqli_connect("localhost","root","123456","a");
$sql = "SELECT * from user where uAccount = '".$_GET['uAccount']."'"; 
$result = mysqli_query($link,$sql);


$row = mysqli_fetch_array($result);

echo "<center>";
echo $row["uName"];
echo "歡迎回來";
echo "<br>";
echo "你的上一次登入時間為";
echo $row['ulastIn'];
echo "<br>";
echo "你的登入次數為".$row['ulogNum']."次";
echo "<br>";
echo "</center>";

?>