<?php

function add($a,$b)
{
	$sum = $a + $b;
	return $sum;
}
function sub($a,$b)
{

	$sum = $a - $b;
	return $sum;
function multi($a,$b)
{

	$sum = $a * $b;
	return $sum;
function div($a,$b)
{

	$sum = $a / $b;
	return $sum;
	
	
?>

<?php echo add(1,1); ?>